FPGA Simon Says — supplied project source

Eight Verilog design modules and three component testbenches.
File names have been normalised; source contents are unchanged.
Top-level module: Top_SS. Reset initialises the game and RNG.
Board pin constraints and a tool project are not included.
The supplied testbenches are component stimulus, not a full-game verification suite.
